<template>
  <!-- <v-progress indeterminate style-progress="tiny" style-progress-bar="gradient"></v-progress> -->
  <v-spinner></v-spinner>
</template>

<script>
export default {
  setup() {
    
  },
}
</script>
