<template>
  <v-navbar class="px-4 py-3 mb-6">
    <span class="text-xl font-bold">
      Vue-icons
    </span>
  </v-navbar>
  <IconsMain></IconsMain>
</template>

<script setup>
import IconsMain from "./components/IconsMain.vue"
</script>

<style>
</style>
